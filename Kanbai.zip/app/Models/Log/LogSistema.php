<?php

namespace App\Models\Log;

use Illuminate\Database\Eloquent\Model;

class LogSistema extends Model
{
    //
}
